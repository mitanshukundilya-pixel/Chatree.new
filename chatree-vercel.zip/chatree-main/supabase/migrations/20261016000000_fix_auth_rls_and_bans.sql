-- 1. Membership helper (SECURITY DEFINER avoids the self-referencing RLS recursion)
CREATE OR REPLACE FUNCTION public.is_conversation_member(_conversation_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.conversation_members
    WHERE conversation_id = _conversation_id AND user_id = _user_id
  )
$$;

-- 2. Ban helpers
CREATE OR REPLACE FUNCTION public.is_banned(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.banned_users WHERE user_id = _user_id)
$$;

CREATE OR REPLACE FUNCTION public.is_current_user_banned()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.is_banned(auth.uid())
$$;

-- 3. Fix conversation_members SELECT (was infinitely recursive)
DROP POLICY IF EXISTS "Members can view their memberships" ON public.conversation_members;
CREATE POLICY "Members can view their memberships" ON public.conversation_members
  FOR SELECT TO authenticated
  USING (public.is_conversation_member(conversation_id, auth.uid()));

-- 4. Fix conversations SELECT (unqualified `id` resolved to conversation_members.id,
--    so it never matched; creators also need to read the row they just inserted)
DROP POLICY IF EXISTS "Members can view conversations" ON public.conversations;
CREATE POLICY "Members can view conversations" ON public.conversations
  FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR public.is_conversation_member(id, auth.uid()));

-- 5. Enforce bans on writes (RESTRICTIVE = must pass in addition to other policies)
CREATE POLICY "Banned users cannot send messages" ON public.messages
  AS RESTRICTIVE FOR INSERT TO authenticated
  WITH CHECK (NOT public.is_banned(auth.uid()));

CREATE POLICY "Banned users cannot create conversations" ON public.conversations
  AS RESTRICTIVE FOR INSERT TO authenticated
  WITH CHECK (NOT public.is_banned(auth.uid()));

-- 6. Make yourself admin (run once, replace the email):
-- INSERT INTO public.user_roles (user_id, role)
-- SELECT id, 'admin' FROM auth.users WHERE email = 'you@example.com';
