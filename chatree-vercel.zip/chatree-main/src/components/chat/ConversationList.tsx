import { formatDistanceToNow } from "date-fns";
import { Plus, Search } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import type { Conversation } from "@/hooks/useConversations";

interface Props {
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNewChat: () => void;
}

export default function ConversationList({ conversations, activeId, onSelect, onNewChat }: Props) {
  const { user } = useAuth();
  const [search, setSearch] = useState("");

  const getDisplayName = (conv: Conversation) => {
    if (conv.is_group) return conv.name ?? "Group Chat";
    const other = conv.members?.find((m) => m.user_id !== user?.id);
    return other?.profile?.display_name ?? "Unknown";
  };

  const getAvatar = (conv: Conversation) => {
    if (conv.is_group) return conv.avatar_url;
    const other = conv.members?.find((m) => m.user_id !== user?.id);
    return other?.profile?.avatar_url;
  };

  const getIsOnline = (conv: Conversation) => {
    if (conv.is_group) return false;
    const other = conv.members?.find((m) => m.user_id !== user?.id);
    return other?.profile?.is_online ?? false;
  };

  const filtered = conversations.filter((c) =>
    getDisplayName(c).toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex h-full flex-col bg-sidebar">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4">
        <h1 className="text-lg font-semibold text-sidebar-foreground">Chats</h1>
        <button
          onClick={onNewChat}
          className="flex h-8 w-8 items-center justify-center rounded-full text-sidebar-foreground/70 transition-colors hover:bg-sidebar-accent active:scale-95"
        >
          <Plus className="h-5 w-5" />
        </button>
      </div>

      {/* Search */}
      <div className="px-4 pb-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-sidebar-foreground/40" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search conversations…"
            className="w-full rounded-lg bg-sidebar-accent py-2 pl-9 pr-3 text-sm text-sidebar-foreground placeholder:text-sidebar-foreground/40 outline-none"
          />
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {filtered.map((conv) => {
          const isActive = conv.id === activeId;
          const avatar = getAvatar(conv);
          const name = getDisplayName(conv);
          const isOnline = getIsOnline(conv);
          const initials = name.slice(0, 2).toUpperCase();

          return (
            <button
              key={conv.id}
              onClick={() => onSelect(conv.id)}
              className={`flex w-full items-center gap-3 px-4 py-3 text-left transition-colors ${
                isActive ? "bg-sidebar-accent" : "hover:bg-sidebar-accent/50"
              }`}
            >
              <div className="relative flex-shrink-0">
                {avatar ? (
                  <img src={avatar} alt="" className="h-11 w-11 rounded-full object-cover" />
                ) : (
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/20 text-sm font-medium text-sidebar-primary">
                    {initials}
                  </div>
                )}
                {isOnline && (
                  <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-sidebar bg-online" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <span className="truncate text-sm font-medium text-sidebar-foreground">{name}</span>
                  {conv.last_message && (
                    <span className="ml-2 flex-shrink-0 text-[11px] text-sidebar-foreground/40">
                      {formatDistanceToNow(new Date(conv.last_message.created_at), { addSuffix: false })}
                    </span>
                  )}
                </div>
                <p className="mt-0.5 truncate text-xs text-sidebar-foreground/50">
                  {conv.last_message?.content ?? "No messages yet"}
                </p>
              </div>
            </button>
          );
        })}

        {filtered.length === 0 && (
          <div className="px-4 py-8 text-center text-sm text-sidebar-foreground/40">
            {search ? "No conversations found" : "No conversations yet"}
          </div>
        )}
      </div>
    </div>
  );
}
