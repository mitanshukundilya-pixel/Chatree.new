import { format } from "date-fns";
import { Check, CheckCheck } from "lucide-react";
import type { Message } from "@/hooks/useMessages";

interface Props {
  message: Message;
  isOwn: boolean;
  showAvatar: boolean;
}

export default function MessageBubble({ message, isOwn, showAvatar }: Props) {
  const time = format(new Date(message.created_at), "HH:mm");

  return (
    <div className={`flex gap-2 px-4 ${isOwn ? "flex-row-reverse" : ""} animate-fade-in`}>
      {/* Avatar */}
      {!isOwn && showAvatar ? (
        <div className="flex-shrink-0 pt-1">
          {message.sender_profile?.avatar_url ? (
            <img
              src={message.sender_profile.avatar_url}
              alt=""
              className="h-7 w-7 rounded-full object-cover"
            />
          ) : (
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-muted text-xs font-medium text-muted-foreground">
              {(message.sender_profile?.display_name ?? "?").slice(0, 1).toUpperCase()}
            </div>
          )}
        </div>
      ) : !isOwn ? (
        <div className="w-7 flex-shrink-0" />
      ) : null}

      {/* Bubble */}
      <div
        className={`max-w-[75%] rounded-2xl px-3.5 py-2 shadow-sm ${
          isOwn
            ? "bg-chat-own rounded-tr-md"
            : "bg-chat-other rounded-tl-md"
        }`}
      >
        {!isOwn && showAvatar && message.sender_profile?.display_name && (
          <p className="mb-0.5 text-[11px] font-medium text-primary">
            {message.sender_profile.display_name}
          </p>
        )}
        <p className="text-sm leading-relaxed text-foreground break-words overflow-wrap-anywhere">
          {message.content}
        </p>
        <div className={`mt-1 flex items-center gap-1 ${isOwn ? "justify-end" : ""}`}>
          <span className="text-[10px] text-chat-timestamp">{time}</span>
          {isOwn && (
            message.status === "read" ? (
              <CheckCheck className="h-3.5 w-3.5 text-primary" />
            ) : (
              <Check className="h-3.5 w-3.5 text-chat-timestamp" />
            )
          )}
        </div>
      </div>
    </div>
  );
}
