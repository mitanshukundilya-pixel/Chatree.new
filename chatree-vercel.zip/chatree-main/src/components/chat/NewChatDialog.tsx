import { useState } from "react";
import { X, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useProfiles } from "@/hooks/useProfiles";

interface Props {
  open: boolean;
  onClose: () => void;
  onCreated: (conversationId: string) => void;
}

export default function NewChatDialog({ open, onClose, onCreated }: Props) {
  const { user } = useAuth();
  const profiles = useProfiles();
  const [search, setSearch] = useState("");
  const [creating, setCreating] = useState<string | null>(null);

  if (!open) return null;

  const filtered = profiles.filter((p) =>
    (p.display_name ?? "").toLowerCase().includes(search.toLowerCase())
  );

  const startChat = async (otherUserId: string) => {
    if (!user || creating) return;
    setCreating(otherUserId);

    // Create conversation
    const { data: conv, error } = await supabase
      .from("conversations")
      .insert({ created_by: user.id, is_group: false })
      .select()
      .single();

    if (error || !conv) {
      setCreating(null);
      return;
    }

    // Add both members
    await supabase.from("conversation_members").insert([
      { conversation_id: conv.id, user_id: user.id, role: "admin" },
      { conversation_id: conv.id, user_id: otherUserId, role: "member" },
    ]);

    setCreating(null);
    onCreated(conv.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/20 backdrop-blur-sm" onClick={onClose}>
      <div
        className="mx-4 w-full max-w-md animate-fade-in rounded-2xl bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 className="text-base font-semibold text-foreground">New Conversation</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground hover:bg-muted active:scale-95">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="px-5 py-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search users…"
              className="w-full rounded-lg bg-muted py-2.5 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground outline-none"
              autoFocus
            />
          </div>
        </div>

        <div className="max-h-72 overflow-y-auto scrollbar-thin pb-2">
          {filtered.map((profile) => (
            <button
              key={profile.id}
              onClick={() => startChat(profile.id)}
              disabled={creating === profile.id}
              className="flex w-full items-center gap-3 px-5 py-2.5 text-left transition-colors hover:bg-muted active:scale-[0.99] disabled:opacity-50"
            >
              {profile.avatar_url ? (
                <img src={profile.avatar_url} alt="" className="h-10 w-10 rounded-full object-cover" />
              ) : (
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-medium text-primary">
                  {(profile.display_name ?? "?").slice(0, 2).toUpperCase()}
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-foreground">{profile.display_name}</p>
                <p className="text-xs text-muted-foreground">{profile.is_online ? "Online" : "Offline"}</p>
              </div>
              {creating === profile.id && (
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
              )}
            </button>
          ))}

          {filtered.length === 0 && (
            <p className="py-6 text-center text-sm text-muted-foreground">
              {search ? "No users found" : "No other users yet"}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
