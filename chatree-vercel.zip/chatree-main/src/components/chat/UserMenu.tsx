import { LogOut, Settings, Shield } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";

export default function UserMenu() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const displayName = user?.user_metadata?.full_name ?? user?.user_metadata?.name ?? user?.email?.split("@")[0] ?? "User";
  const avatar = user?.user_metadata?.avatar_url ?? user?.user_metadata?.picture;

  return (
    <div className="flex items-center gap-3 border-t border-sidebar-border bg-sidebar px-4 py-3">
      {avatar ? (
        <img src={avatar} alt="" className="h-9 w-9 rounded-full object-cover" />
      ) : (
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-sidebar-accent text-sm font-medium text-sidebar-foreground">
          {displayName.slice(0, 1).toUpperCase()}
        </div>
      )}
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-sidebar-foreground">{displayName}</p>
      </div>
      <button
        onClick={() => navigate("/admin")}
        className="flex h-7 w-7 items-center justify-center rounded-full text-sidebar-foreground/50 hover:bg-sidebar-accent active:scale-95"
        title="Admin Panel"
      >
        <Shield className="h-4 w-4" />
      </button>
      <button
        onClick={signOut}
        className="flex h-7 w-7 items-center justify-center rounded-full text-sidebar-foreground/50 hover:bg-sidebar-accent active:scale-95"
        title="Sign out"
      >
        <LogOut className="h-4 w-4" />
      </button>
    </div>
  );
}
