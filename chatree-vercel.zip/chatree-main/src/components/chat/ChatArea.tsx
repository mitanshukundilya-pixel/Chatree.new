import { useEffect, useRef } from "react";
import { Phone, Video, MoreVertical, ArrowLeft } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useMessages } from "@/hooks/useMessages";
import type { Conversation } from "@/hooks/useConversations";
import MessageBubble from "./MessageBubble";
import MessageInput from "./MessageInput";

interface Props {
  conversation: Conversation | null;
  onBack?: () => void;
}

export default function ChatArea({ conversation, onBack }: Props) {
  const { user } = useAuth();
  const { messages, loading, sendMessage } = useMessages(conversation?.id ?? null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  if (!conversation) {
    return (
      <div className="flex h-full flex-col items-center justify-center bg-background">
        <div className="animate-fade-in text-center">
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-muted">
            <svg className="h-10 w-10 text-muted-foreground/50" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 0 1-2.555-.337A5.972 5.972 0 0 1 5.41 20.97a5.969 5.969 0 0 1-.474-.065 4.48 4.48 0 0 0 .978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25Z" />
            </svg>
          </div>
          <h2 className="text-lg font-medium text-foreground">Select a conversation</h2>
          <p className="mt-1 text-sm text-muted-foreground">Choose a chat to start messaging</p>
        </div>
      </div>
    );
  }

  const getDisplayName = () => {
    if (conversation.is_group) return conversation.name ?? "Group Chat";
    const other = conversation.members?.find((m) => m.user_id !== user?.id);
    return other?.profile?.display_name ?? "Unknown";
  };

  const getIsOnline = () => {
    if (conversation.is_group) return false;
    const other = conversation.members?.find((m) => m.user_id !== user?.id);
    return other?.profile?.is_online ?? false;
  };

  const getAvatar = () => {
    if (conversation.is_group) return conversation.avatar_url;
    const other = conversation.members?.find((m) => m.user_id !== user?.id);
    return other?.profile?.avatar_url;
  };

  const name = getDisplayName();
  const isOnline = getIsOnline();
  const avatar = getAvatar();

  return (
    <div className="flex h-full flex-col bg-background">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-border bg-card px-4 py-3 shadow-sm">
        {onBack && (
          <button onClick={onBack} className="mr-1 flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground hover:bg-muted active:scale-95 md:hidden">
            <ArrowLeft className="h-5 w-5" />
          </button>
        )}
        <div className="relative">
          {avatar ? (
            <img src={avatar} alt="" className="h-10 w-10 rounded-full object-cover" />
          ) : (
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-medium text-primary">
              {name.slice(0, 2).toUpperCase()}
            </div>
          )}
          {isOnline && (
            <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-card bg-online" />
          )}
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="truncate text-sm font-semibold text-foreground">{name}</h2>
          <p className="text-xs text-muted-foreground">{isOnline ? "Online" : "Offline"}</p>
        </div>
        <div className="flex items-center gap-1">
          <button className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground hover:bg-muted active:scale-95">
            <Phone className="h-4 w-4" />
          </button>
          <button className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground hover:bg-muted active:scale-95">
            <Video className="h-4 w-4" />
          </button>
          <button className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground hover:bg-muted active:scale-95">
            <MoreVertical className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto scrollbar-thin py-4 space-y-1.5">
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        ) : messages.length === 0 ? (
          <div className="py-8 text-center text-sm text-muted-foreground">
            No messages yet. Say hello! 👋
          </div>
        ) : (
          messages.map((msg, i) => {
            const isOwn = msg.sender_id === user?.id;
            const prevMsg = messages[i - 1];
            const showAvatar = !prevMsg || prevMsg.sender_id !== msg.sender_id;

            return (
              <MessageBubble
                key={msg.id}
                message={msg}
                isOwn={isOwn}
                showAvatar={showAvatar}
              />
            );
          })
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <MessageInput onSend={sendMessage} />
    </div>
  );
}
