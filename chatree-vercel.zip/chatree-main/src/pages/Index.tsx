import { useAuth } from "@/contexts/AuthContext";
import AuthPage from "./AuthPage";
import ChatPage from "./ChatPage";

export default function Index() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  return user ? <ChatPage /> : <AuthPage />;
}
