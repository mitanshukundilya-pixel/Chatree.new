import { useState } from "react";
import { useConversations } from "@/hooks/useConversations";
import ConversationList from "@/components/chat/ConversationList";
import ChatArea from "@/components/chat/ChatArea";
import NewChatDialog from "@/components/chat/NewChatDialog";
import UserMenu from "@/components/chat/UserMenu";
import { useIsMobile } from "@/hooks/use-mobile";

export default function ChatPage() {
  const { conversations, loading } = useConversations();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [newChatOpen, setNewChatOpen] = useState(false);
  const isMobile = useIsMobile();

  const activeConversation = conversations.find((c) => c.id === activeId) ?? null;

  const showSidebar = !isMobile || !activeId;
  const showChat = !isMobile || !!activeId;

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      {showSidebar && (
        <div className={`flex flex-col ${isMobile ? "w-full" : "w-80 border-r border-sidebar-border"}`}>
          <div className="flex-1 overflow-hidden">
            <ConversationList
              conversations={conversations}
              activeId={activeId}
              onSelect={setActiveId}
              onNewChat={() => setNewChatOpen(true)}
            />
          </div>
          <UserMenu />
        </div>
      )}

      {/* Chat area */}
      {showChat && (
        <div className="flex-1">
          <ChatArea
            conversation={activeConversation}
            onBack={isMobile ? () => setActiveId(null) : undefined}
          />
        </div>
      )}

      <NewChatDialog
        open={newChatOpen}
        onClose={() => setNewChatOpen(false)}
        onCreated={(id) => setActiveId(id)}
      />
    </div>
  );
}
