import { useEffect, useState } from "react";
import { ArrowLeft, Ban, Shield, Users, MessageSquare, UserCheck } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import type { Tables } from "@/integrations/supabase/types";

export default function AdminPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [profiles, setProfiles] = useState<Tables<"profiles">[]>([]);
  const [bannedUsers, setBannedUsers] = useState<Tables<"banned_users">[]>([]);
  const [stats, setStats] = useState({ users: 0, conversations: 0, messages: 0 });

  useEffect(() => {
    if (!user) return;

    // Check admin role
    supabase.rpc("has_role", { _user_id: user.id, _role: "admin" }).then(({ data }) => {
      setIsAdmin(data === true);
    });

    // Fetch profiles
    supabase.from("profiles").select("*").then(({ data }) => setProfiles(data ?? []));

    // Fetch banned users
    supabase.from("banned_users").select("*").then(({ data }) => setBannedUsers(data ?? []));

    // Stats
    supabase.from("profiles").select("id", { count: "exact", head: true }).then(({ count }) => {
      setStats((s) => ({ ...s, users: count ?? 0 }));
    });
    supabase.from("conversations").select("id", { count: "exact", head: true }).then(({ count }) => {
      setStats((s) => ({ ...s, conversations: count ?? 0 }));
    });
    supabase.from("messages").select("id", { count: "exact", head: true }).then(({ count }) => {
      setStats((s) => ({ ...s, messages: count ?? 0 }));
    });
  }, [user]);

  if (isAdmin === null) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-background">
        <Shield className="mb-4 h-12 w-12 text-muted-foreground" />
        <h1 className="text-lg font-semibold text-foreground">Access Denied</h1>
        <p className="mt-1 text-sm text-muted-foreground">You need admin privileges to view this page.</p>
        <button onClick={() => navigate("/")} className="mt-4 text-sm font-medium text-primary hover:underline">
          Back to Chat
        </button>
      </div>
    );
  }

  const isBanned = (userId: string) => bannedUsers.some((b) => b.user_id === userId);

  const toggleBan = async (userId: string) => {
    if (isBanned(userId)) {
      await supabase.from("banned_users").delete().eq("user_id", userId);
      setBannedUsers((prev) => prev.filter((b) => b.user_id !== userId));
    } else {
      const { data } = await supabase
        .from("banned_users")
        .insert({ user_id: userId, banned_by: user!.id, reason: "Banned by admin" })
        .select()
        .single();
      if (data) setBannedUsers((prev) => [...prev, data]);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card px-6 py-4">
        <div className="mx-auto flex max-w-5xl items-center gap-3">
          <button onClick={() => navigate("/")} className="flex h-8 w-8 items-center justify-center rounded-full text-muted-foreground hover:bg-muted active:scale-95">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <Shield className="h-5 w-5 text-primary" />
          <h1 className="text-lg font-semibold text-foreground">Admin Panel</h1>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-6 py-8">
        {/* Stats */}
        <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {[
            { label: "Total Users", value: stats.users, icon: Users },
            { label: "Conversations", value: stats.conversations, icon: MessageSquare },
            { label: "Messages", value: stats.messages, icon: UserCheck },
          ].map(({ label, value, icon: Icon }) => (
            <div key={label} className="rounded-xl border border-border bg-card p-5 shadow-sm animate-fade-in">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-semibold tabular-nums text-foreground">{value}</p>
                  <p className="text-xs text-muted-foreground">{label}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* User Management */}
        <div className="rounded-xl border border-border bg-card shadow-sm">
          <div className="border-b border-border px-5 py-4">
            <h2 className="text-base font-semibold text-foreground">User Management</h2>
          </div>
          <div className="divide-y divide-border">
            {profiles.map((profile) => (
              <div key={profile.id} className="flex items-center gap-3 px-5 py-3">
                {profile.avatar_url ? (
                  <img src={profile.avatar_url} alt="" className="h-9 w-9 rounded-full object-cover" />
                ) : (
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-sm font-medium text-muted-foreground">
                    {(profile.display_name ?? "?").slice(0, 1).toUpperCase()}
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-foreground">{profile.display_name ?? "Unknown"}</p>
                  <p className="text-xs text-muted-foreground">
                    {profile.is_online ? "Online" : `Last seen ${profile.last_seen ? new Date(profile.last_seen).toLocaleDateString() : "never"}`}
                  </p>
                </div>
                {profile.id !== user?.id && (
                  <button
                    onClick={() => toggleBan(profile.id)}
                    className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors active:scale-95 ${
                      isBanned(profile.id)
                        ? "bg-destructive/10 text-destructive hover:bg-destructive/20"
                        : "bg-muted text-muted-foreground hover:bg-muted/80"
                    }`}
                  >
                    <Ban className="h-3.5 w-3.5" />
                    {isBanned(profile.id) ? "Unban" : "Ban"}
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
