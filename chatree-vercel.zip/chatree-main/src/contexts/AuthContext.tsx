import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import type { User, Session } from "@supabase/supabase-js";

type Provider = "google" | "apple";

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  authError: string | null;
  signInWithGoogle: () => Promise<void>;
  signInWithApple: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Lovable's OAuth broker only works on Lovable-hosted domains.
// Everywhere else (localhost, Vercel, custom host) use Supabase OAuth directly.
const isLovableHost = () =>
  /(^|\.)lovable\.(app|dev)$|\.lovableproject\.com$/.test(window.location.hostname);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  // Sign out banned accounts immediately.
  const enforceBan = async (s: Session | null) => {
    if (!s) return false;
    const { data } = await supabase.rpc("is_current_user_banned" as never);
    if (data === true) {
      await supabase.auth.signOut();
      setAuthError("This account has been suspended.");
      return true;
    }
    return false;
  };

  useEffect(() => {
    const apply = async (s: Session | null) => {
      if (await enforceBan(s)) {
        setSession(null);
        setUser(null);
      } else {
        setSession(s);
        setUser(s?.user ?? null);
      }
      setLoading(false);
    };

    // Keep this callback synchronous-ish: defer Supabase calls to avoid auth deadlocks.
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, s) => {
      setTimeout(() => void apply(s), 0);
    });

    supabase.auth.getSession().then(({ data: { session: s } }) => void apply(s));

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (provider: Provider) => {
    setAuthError(null);
    try {
      if (isLovableHost()) {
        const result = await lovable.auth.signInWithOAuth(provider, {
          redirect_uri: window.location.origin,
        });
        if ("error" in result && result.error) throw result.error;
      } else {
        const { error } = await supabase.auth.signInWithOAuth({
          provider,
          options: { redirectTo: window.location.origin },
        });
        if (error) throw error;
      }
    } catch (e) {
      setAuthError(e instanceof Error ? e.message : "Sign-in failed. Please try again.");
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        loading,
        authError,
        signInWithGoogle: () => signIn("google"),
        signInWithApple: () => signIn("apple"),
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
